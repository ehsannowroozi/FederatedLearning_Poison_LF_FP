import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.model_selection import train_test_split
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
from matplotlib import pyplot as plt
from sklearn.metrics import accuracy_score
from sklearn import preprocessing
import random

import openpyxl

# Create a new workbook and select the active sheet
workbook = openpyxl.Workbook()
sheet = workbook.active
data_rows = []

# from aijack.attack import GANAttackManager
from aijack.collaborative import FedAVGClient, FedAVGServer
from aijack.utils import NumpyDataset
import pickle

dataset = np.loadtxt('UNSW.csv', delimiter=",", dtype=np.float32)
print(dataset.shape)
np.nan_to_num(dataset, copy=False)

# half_of_dataset = dataset.shape[0]// 2
# print(dataset.shape[0]- half_of_dataset)
# print(half_of_dataset)
rows_value = 500
X = dataset[:rows_value, :-1]  # please make changes in this line

Y = dataset[:rows_value, -1]  # please make changes in this line
Y = np.where(Y > 0.5, 1, 0)
feature_column = dataset[:rows_value, 1]
average_zero = np.mean(feature_column[Y == 0])
average_one = np.mean(feature_column[Y == 1])

column_index = 1
column_values = X[:, column_index]

min_value = np.min(column_values)
max_value = np.max(column_values)

normalized_avg_value_0 = (average_zero - min_value) / (max_value - min_value)
normalized_avg_value_1 = (average_one - min_value) / (max_value - min_value)
# if(np.isnan(average_zero)):
#     print("Average when output 0 is Not a number")
# elif (np.isnan(average_one)):
#     print("Average when output 1 is not a number")
print("Average when output is 0 :", average_zero)
print("Average when output is 1 : ", average_one)

print("Normalized average value for 0  = ", normalized_avg_value_0)
print("Normalized average Value for 1 = ", normalized_avg_value_1)

# splitting dataset into training and testing dataset
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, random_state=1)

# Splitting the data into two clients

half_of_dataset = X_train.shape[0] // 2
print("Half of the dataset is : ", half_of_dataset)

cl1_X = X_train[:half_of_dataset]
cl1_Y = Y_train[:half_of_dataset]

cl2_X = X_train[half_of_dataset:]
cl2_Y = Y_train[half_of_dataset:]

X_train = preprocessing.normalize(X_train, norm='l2')
X_test = preprocessing.normalize(X_test, norm='l2')

cl1_X = preprocessing.normalize(cl1_X, norm='l2')
cl2_X = preprocessing.normalize(cl2_X, norm='l2')

# Below is adding the new axis
X_train = np.expand_dims(X_train, axis=1)  # 1st time expand dimension
X_test = np.expand_dims(X_test, axis=1)
X_test = np.expand_dims(X_test, axis=1)
X_train = np.expand_dims(X_train, axis=1)  # 2nd time expand dimension

cl1_X = np.expand_dims(cl1_X, axis=1)
cl1_X = np.expand_dims(cl1_X, axis=1)

cl2_X = np.expand_dims(cl2_X, axis=1)
cl2_X = np.expand_dims(cl2_X, axis=1)

print(cl1_X.shape)
print(cl2_X.shape)

# Splitting data into validation and testing
half_valid_test = X_test.shape[0] // 2
X_validation = X_test[:half_valid_test]
Y_validation = Y_test[:half_valid_test]
X_testing = X_test[half_valid_test:]
Y_testing = Y_test[half_valid_test:]
features_flipped_test_data = X_testing


column_index = 1  # Please change this column according to the dataset

#create an array with values where label = 0

# Reshape the array
reshaped_array = cl1_X.reshape(200, 76)

# Select the desired column
column_values = reshaped_array[cl1_Y == 0, column_index]

# Find unique values
unique_values = np.unique(column_values)
print("Length of unqiue values array = ",len(unique_values))

# select a random value and assign it if label = 1



features_flipped_test_data[Y_testing == 0, 0, 0, column_index] = normalized_avg_value_1

features_flipped_test_data[Y_testing == 1, 0, 0, column_index] = normalized_avg_value_0

# print(features_flipped_test_data[1])


# model is defiend below
batch_size = 128
height = 19
width = 52


class Network_DNN_2(nn.Module):
    def __init__(self, feature_size):
        super(Network_DNN_2, self).__init__()
        self.dropout_p = 0.2
        self.num_classes = 2
        self.feature_size = feature_size

        self.dropout = nn.Dropout(p=self.dropout_p)
        self.dense_relu1 = nn.ReLU()
        self.dense_relu2 = nn.ReLU()
        # self.dense_relu3 = nn.ReLU()
        # self.dense_relu4 = nn.ReLU()
        # self.dense_relu5 = nn.ReLU()
        # self.dense_relu6 = nn.ReLU()
        # self.dense_relu7 = nn.ReLU()
        # self.dense_relu8 = nn.ReLU()

        self.Batch1 = nn.BatchNorm1d(2048)
        self.Batch2 = nn.BatchNorm1d(1024)
        # self.Batch3 = nn.BatchNorm1d(512)
        # self.Batch4 = nn.BatchNorm1d(256)
        # self.Batch5 = nn.BatchNorm1d(128)
        # self.Batch6 = nn.BatchNorm1d(64)
        # self.Batch7 = nn.BatchNorm1d(32)

        self.dense1 = nn.Linear(feature_size, 2048)  # ( size )
        self.dense2 = nn.Linear(2048, 1024)
        # self.dense3 = nn.Linear(1024, 512)
        # self.dense4 = nn.Linear(512, 256)
        # self.dense5 = nn.Linear(256, 128)
        # self.dense6 = nn.Linear(128, 64)
        # self.dense7 = nn.Linear(feature_size, 32)
        # self.dense8 = nn.Linear(feature_size, 16)
        self.pred_layer = nn.Linear(1024, self.num_classes)
        self.init_weight()

    def init_weight(self):
        for m in self._modules:
            if type(m) == nn.Linear:
                nn.init.kaiming_uniform_(m.weight, nonlinearity='relu')
                m.bias.data.fill_(0.01)

    def forward(self, x):
        x = x.float()
        # x = torch.flatten(x, start_dim=0, end_dim=0)
        x = torch.reshape(x, (
        len(x), x.shape[1] * x.shape[2] * x.shape[3]))  # len(x) = batch_size ,feature_size= 65 ==> 1 * 1 * 65 = 65
        x = self.dense1(x)
        # x = self.Batch1(x)
        x = self.dense_relu1(x)
        x = self.dropout(x)
        #
        x = self.dense2(x)
        # x = self.Batch2(x)
        x = self.dense_relu2(x)
        x = self.dropout(x)
        #
        # x = self.dense3(x)
        # #x = self.Batch3(x)
        # x = self.dense_relu3(x)
        # x = self.dropout(x)
        #
        # x = self.dense4(x)
        # #x = self.Batch4(x)
        # x = self.dense_relu4(x)
        # x = self.dropout(x)
        #
        # x = self.dense5(x)
        # #x = self.Batch5(x)
        # x = self.dense_relu5(x)
        # x = self.dropout(x)
        #
        # x = self.dense6(x)
        # #x = self.Batch6(x)
        # x = self.dense_relu6(x)
        # x = self.dropout(x)

        # x = self.dense7(x)
        # #x = self.Batch7(x)
        # x = self.dense_relu7(x)
        # x = self.dropout(x)

        # x = self.dense8(x)
        # # x = self.Batch7(x)
        # x = self.dense_relu8(x)
        # x = self.dropout(x)

        preds = self.pred_layer(x)
        preds = torch.log_softmax(preds, dim=1)
        return preds


def prepare_dataloaders(run, attack_percent):
    # ************** Code for attack ***************
    # **********************************************

    percent = 0
    if (run == 1):
        number = attack_percent
        percent = int(len(cl1_Y) * (number / 100))

    for i in range(percent):
        random_index = random.randint(0, len(unique_values)-1)
        if cl1_Y[i] == 1:
            cl1_X[i, 0, 0, column_index] = unique_values[random_index]
    # **********************************************
    # **********************************************

    transform = transforms.Compose(
        [transforms.ToTensor(), transforms.Normalize((0.5), (0.5))]
    )
    global_trainset = NumpyDataset(
        X_validation,
        Y_validation,
        transform=transform)
    global_trainloader = torch.utils.data.DataLoader(
        global_trainset, batch_size=1000, shuffle=True, num_workers=0
    )
    global_ASR_test = NumpyDataset(
        features_flipped_test_data,
        Y_testing,
        transform=transform
    )
    global_ASR = torch.utils.data.DataLoader(
        global_ASR_test, batch_size=1000, shuffle=True, num_workers=0
    )

    global_trainset2 = NumpyDataset(
        X_testing,
        Y_testing,
        transform=transform)
    global_trainloader2 = torch.utils.data.DataLoader(  #
        global_trainset2, batch_size=1000, shuffle=True, num_workers=0
    )

    trainset_1 = NumpyDataset(cl1_X, cl1_Y, transform=transform)
    trainloader_1 = torch.utils.data.DataLoader(
        trainset_1, batch_size=batch_size, shuffle=True, num_workers=0
    )

    trainset_2 = NumpyDataset(cl2_X, cl2_Y, transform=transform)
    trainloader_2 = torch.utils.data.DataLoader(
        trainset_2, batch_size=batch_size, shuffle=True, num_workers=0
    )

    Y_train1 = np.where(Y_train > 0.5, 1, 0)

    return X_train, Y_train1, [trainloader_1, trainloader_2], global_trainloader, [200,
                                                                                   200], global_trainloader2, global_ASR


class LeNet(nn.Module):  # (size - kernel size + 2* padding)/stride + 1 =>output size of layer
    def __init__(self, channel=1, hidden=512, num_classes=2):  #
        super(LeNet, self).__init__()
        act = nn.Sigmoid
        self.body = nn.Sequential(
            nn.Conv2d(1, 16, kernel_size=2, padding=1, stride=2),  # width = 25 , height= 9 # stride is jump
            act(),
            nn.Conv2d(16, 16, kernel_size=2, padding=1, stride=1),  # widht = 23 , height = 7
            act(),
            nn.Conv2d(16, 2, kernel_size=2, padding=1, stride=1),  # w=21 , height = 5
            act(),
        )
        self.fc = nn.Sequential(
            nn.Linear(hidden, num_classes)
        )
        self.init_weight()

    def init_weight(self):
        for m in self._modules:
            if type(m) == nn.Linear:
                torch.nn.init.xavier_uniform(m.weight)
                m.bias.data.fill_(0.01)
            if type(m) == nn.Conv2d:
                torch.nn.init.xavier_uniform(m.weight)
                m.bias.data.fill_(0.01)

    def forward(self, x):
        out = self.body(x)
        out = out.view(out.size(0), -1)
        out = self.fc(out)
        return out


def main(attack_percent):
    device = torch.device("cuda:0") if torch.cuda.is_available() else "cpu"
    print(device)
    best_score = 0
    best_fold = 1
    X_test1, y_test, trainloaders, global_trainloader, dataset_nums, global2, _ = prepare_dataloaders(1, attack_percent)

    criterion = nn.CrossEntropyLoss()
    client_num = 2
    # adversary_client_id = 1
    # target_label = 3

    # feature_size = height * width
    feature_size = X_train.shape[3]
    net_1 = Network_DNN_2(feature_size)  # LeNet(channel=1, hidden=512, num_classes=2)
    client_1 = FedAVGClient(net_1, user_id=0, send_gradient=False)
    client_1.to(device)

    random_lr = round(random.uniform(0.0010, 0.0099), 4)
    random_weight_decay = round(random.uniform(1e-7, 1e-5), 4)
    optimizer_1 = optim.SGD(
        client_1.parameters(), lr=random_lr, weight_decay=random_weight_decay, momentum=0.9
    )

    net_2 = Network_DNN_2(feature_size)
    client_2 = FedAVGClient(net_2, user_id=1, send_gradient=False)
    client_2.to(device)
    optimizer_2 = optim.SGD(
        client_2.parameters(), lr=random_lr, weight_decay=random_weight_decay, momentum=0.9
    )

    clients = [client_1, client_2]
    optimizers = [optimizer_1, optimizer_2]

    global_model = Network_DNN_2(feature_size)
    global_model.to(device)

    server = FedAVGServer(clients, global_model)
    num_of_epochs = 20
    inner_epochs = 5
    for epoch in range(num_of_epochs):
        for client_idx in range(client_num):
            client = clients[client_idx]
            trainloader = trainloaders[client_idx]
            optimizer = optimizers[client_idx]
            running_loss = 0.0
            i = 0
            for l in range(inner_epochs):
                for _, data in enumerate(trainloader, 0):
                    inputs, labels = data
                    inputs = inputs.to(device)
                    labels = labels.to(device)
                    # zero the parameter gradients
                    optimizer.zero_grad()
                    # forward + backward + optimize
                    outputs = client(inputs)
                    loss = criterion(outputs, labels.to(torch.int64))
                    optimizer.step()

                    running_loss += loss.item()
                    i += 1

            print(
                f"epoch {epoch}: client-{client_idx + 1}",
                running_loss / (len(trainloader.dataset)*inner_epochs),
            )
            if epoch == num_of_epochs - 1:
                data_rows.append([f"client- {client_idx + 1} loss ",  running_loss / (len(trainloader.dataset)*inner_epochs)])
        server.receive(use_gradients=True)
        server.update(use_gradients=True)
        server.distribute()

        in_preds = []
        in_label = []
        with torch.no_grad():
            for data in global_trainloader:
                inputs, labels = data
                inputs = inputs.to(device)
                outputs = server.server_model(inputs)
                in_preds.append(outputs)
                in_label.append(labels)
            in_preds = torch.cat(in_preds)
            in_label = torch.cat(in_label)
        temp_acc = 0.0
        print(
            f"epoch {epoch}: accuracy is ",
            accuracy_score(
                np.array(torch.argmax(in_preds, axis=1).cpu()), np.array(in_label)
            ),
        )

        score = accuracy_score(np.array(torch.argmax(in_preds, axis=1).cpu()), np.array(in_label))
        if score >= best_score and epoch >= num_of_epochs - 1:
            best_score = score
            torch.save(server.server_model.state_dict(), "./Model_UNSW/Server_Imran_FL_Row_Test.pt")
            torch.save(client_1.model.state_dict(), "./Model_UNSW/Client1_Imran_FL_Row_Test.pt")
            torch.save(client_2.model.state_dict(), "./Model_UNSW/Client2_Imran_FL_Row_Test.pt")
            # print("BEST SCORE: ", best_score)
    print("BEST SCORE: ", best_score)
    data_rows.append(["Server Accuracy", round(best_score, 4)])


def test():
    net = Network_DNN_2(X_train.shape[3])
    net.load_state_dict(torch.load("./Model_UNSW/Server_Imran_FL_Row_Test.pt"))
    device = torch.device("cuda:0") if torch.cuda.is_available() else "cpu"
    net.to(device)
    X_test, y_test, trainloaders, global_trainloader, dataset_nums, global_trainloader2, _ = prepare_dataloaders(2, 0)
    in_preds = []
    in_label = []
    with torch.no_grad():
        for data in global_trainloader2:
            inputs, labels = data
            inputs = inputs.to(device)
            outputs = net(inputs)
            in_preds.append(outputs)
            in_label.append(labels)
        in_preds = torch.cat(in_preds)
        in_label = torch.cat(in_label)
        test_acc = accuracy_score(np.array(torch.argmax(in_preds, axis=1).cpu()), np.array(in_label))
        return test_acc


def ASR():
    net = Network_DNN_2(X_train.shape[3])
    net.load_state_dict(torch.load("./Model_UNSW/Client1_Imran_FL_Row_Test.pt"))
    device = torch.device("cuda:0") if torch.cuda.is_available() else "cpu"
    net.to(device)
    X_test, y_test, trainloaders, global_trainloader, dataset_nums, global_trainloader2, global_ASR = prepare_dataloaders(
        3, 0)
    in_preds = []
    in_label = []
    with torch.no_grad():
        for data in global_ASR:
            inputs, labels = data
            inputs = inputs.to(device)
            outputs = net(inputs)
            in_preds.append(outputs)
            in_label.append(labels)
        in_preds = torch.cat(in_preds)
        in_label = torch.cat(in_label)
        ASR_success = accuracy_score(np.array(torch.argmax(in_preds, axis=1).cpu()), np.array(in_label))
        return ASR_success


if __name__ == '__main__':
    for i in range(0, 26):
        if (i in [6, 8, 9, 11, 12, 13, 14, 16, 17, 18, 19, 21, 22, 23, 24, 26]):
            continue
        main(i)
        test()
        asr = 0.0
        if i != 0:
            asr = ASR()
            print("Attack Success Rate (ASR) for client 1 with ", i, "% label flipping attack = ", asr)
            data_rows.append(["ASR ", "", i, asr])

        # Write data to rows
        for row_num, row_data in enumerate(data_rows, start=1):
            for col_num, cell_value in enumerate(row_data, start=1):
                sheet.cell(row=row_num, column=col_num).value = cell_value
        # Save the workbook
        workbook.save("UNSW_Feature_1_poison_Results.xlsx")


